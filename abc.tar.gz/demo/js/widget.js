var simpleWidget = Widget.extend({
	attrs : {
		triggers : {
			value : '.nav li',
			getter : function(val){
				return this.$(val);
			},
			readOnly : true
		},
		panels : {
			value : '.content div',
			getter : function(val){
				return this.$(val);
			},
			readOnly : true
		},
		activeIndex : {
			value : 0			  
		}
	},

	event : {
		'click .nav li' : '_switchToEventHandler'
	},

	_onRenderActiveIndex : function(val, prev){
		var triggers = this.get('triggers'),
			panels = this.get('panels');

		triggers.eq(prev).removeClass('active');
		triggers.eq(val).addClass('active');

		panels.eq(prev).hide();
		panels.eq(val).show();
	},

	_switchToEventHandler : function(ev){
		var index = this.get('triggers').index(ev.target);
		this.switchTo(index);
	},

	switchTo : function(index){
		this.set('activeIndex', index);
	},

	setup : function(){
		this.get('panels').hide();
		this.switchTo(this.get('activeIndex'));
	},

	add : function(title, content){
		var li = $('<li>' + title + '</li>'),
			div = $('<div>' + content + '</div>');

		li.appendTo(this.get('triggers')[0].parentNode);
		div.appendTo(this.get('panels')[0].parentNode);

		return this;
	},

	setActiveContent : function(content){
		this.get('panels').eq(this.get('activeIndex')).html(content);
	},

	size : function(){
		return this.get('triggers').length;
	}
});

var tabView = new simpleWidget({
	element : '#demo',
	activeIndex : 0
});
var counter = 1;
