;;$(function(){
	//elemets
	var $wrap = $('#J-wrap'),
		$sections = $('.section'),
		$controller = $('#J-controller'),
		audio = document.getElementById('J-music');

	var galleryBoxWidth = document.documentElement.clientWidth - 48,
		galleryBoxHeight = document.documentElement.clientHeight - 92,
		boxSlice = galleryBoxWidth / galleryBoxHeight;

	var pictures = $('#J-pictures img');

	function loadImg(img){
		var newImg = new Image(),
			src = img.data('src'),
			length = pictures.length,
			index = img.index('#J-pictures img');

		newImg.onload = function(){
			var width = this.width,
				height = this.height,
				imgSlice = width / height;

			if(imgSlice < boxSlice){
				if(height > galleryBoxHeight){
					img.css('height', galleryBoxHeight);
					width = width * galleryBoxHeight / height;
					height = galleryBoxHeight;
				}
			}else{
				if(width > galleryBoxWidth){
					img.css('width', galleryBoxWidth);
					width = galleryBoxWidth;
					height = height * galleryBoxWidth / width;
				}
			}
			img.attr({
				'src' : src,
				'loaded' : true
			}).css({
				left : (galleryBoxWidth - width) / 2,
				top : (galleryBoxHeight - height) / 2 + 40
			});
			if(index + 1 < length){
				loadImg(pictures.eq(index + 1));
			}
		};
		newImg.src = src;
	}

	loadImg(pictures.eq(0));

	function splitTetx(phrase){
		var prevLetter, sentence,
			sentence = $(phrase).html().split("");

		var clientWidth = document.documentElement.clientWidth - 40,
			fontSize = Math.floor(clientWidth / sentence.length);

		$.each(sentence, function(index, val) {
			if(val === " "){
				val = "&nbsp;";
			}
			var letter = $("<div/>", {
						id : "txt" + index
			}).addClass('gallery-sign-word').css('font-size', fontSize + 'px')
			.html(val).appendTo($('#J-gallery-text'));
	
			if(prevLetter) {
				$(letter).css("left", ($(prevLetter)
						.position().left + $(letter).width()) + "px");
			};
			prevLetter = letter;
		});
	}

	splitTetx('#J-phrase');

	function rangeRandom(min, max){
		return min + Math.round(Math.random() * (max -min));
	}

	function zf(){
		return Math.round((Math.random() * 5)) < 2.5 ? -1 : 1;
	}

	var ADDLINES = {
		adyx : function(tl){
			//tl.add -->
		},
		adcj : function(tl){
			//tl.add	   
		}
	}, TIMELINES = {}, CALLBACKS = {
		adyx : {
			switchIn : function(){
				$('#J-gallery-text').css('opacity', '1');
				audio.play();

				var timeline = TIMELINES['adyx'] = TIMELINES['adyx'] || {},
					textTimeLine = timeline.textTimeLine;

				var txt = $('.gallery-sign-word'),
					textBox = $('#J-gallery-text');

				TweenLite.set(textBox, {css:{perspective:500}});

				if(textTimeLine){
					textTimeLine.restart();			
				}else{
					textTimeLine = timeline.textTimeLine = new TimelineMax({
						onUpdate : function(){


						$('#J-line').css('width', textTimeLine.totalProgress() * 50 + '%');
						totalProgressSlider.slider('value', textTimeLine.totalProgress() * 50);


						},
						onComplete : function(){
							var picTimeLine = timeline.picTimeLine;
							$('#J-pictures').css('opacity', 1);
							if(picTimeLine){
								picTimeLine.restart();
							}else{
								picTimeLine = timeline.picTimeLine = new TimelineMax({
									onUpdate : function(){


										var clientWidth = document.documentElement.clientWidth,
											maxV = clientWidth - 12;

										$('#J-line').css('width', 50 + picTimeLine.totalProgress() * 50 + '%');

									   /*
										*if((50 + picTimeLine.totalProgress() * 50) >= maxV){
										*     return false;
										*}
										*/


										totalProgressSlider.slider('value', 
											50 + picTimeLine.totalProgress() * 50 >= maxV ?
											maxV / clientWidth * 100 : 50 + picTimeLine.totalProgress() * 50);
									},
									yoyo : true
								});

								pictures.each(function(index){
									picTimeLine.from(this, 1, {
										left : zf() * rangeRandom(2222, 3333) + 'px',
										top : zf() * rangeRandom(2222, 3333) + 'px'
									});
									if(index !== pictures.length - 1){
										picTimeLine.to(this, 1, {
											left : zf() * rangeRandom(2222, 2555) + 'px',
											top : zf() * rangeRandom(2222, 2555) + 'px',
											delay : 3
										});
									}
								});
							}
						},
						repeat : 1,
						repeatDelay : 1.5,
						yoyo : true
					});

					textTimeLine.staggerFrom(txt, 0.4, {
						alpha:0
					}, 0.06, "textEffect");

					textTimeLine.staggerFrom(txt, 0.8, {
						rotationY:"-270deg", 
						top:80,
						transformOrigin: "50% 50% -80",
						ease:Back.easeOut
					}, 0.06, "textEffect");

					textTimeLine.staggerTo(txt, 0.6, {
						rotationX:"360deg", 
						transformOrigin:"50% 50% 10"
					}, 0.02);	
				}
			},
			switchOut : function(){
				var timeline = TIMELINES['adyx'] || {};
				//暂停music
				//audio.currentTime = 0;
				$('#J-gallery-text').css('opacity', '0');
				$('#J-pictures').css('opacity', 0);
				audio.pause();
				for(var i in timeline){
					if(typeof timeline[i].stop === 'function'){
						timeline[i].stop();
					}
				}
			}
		}
	};

	//动画运行标记
	$wrap.completed = true;

	currentSectionIndex = 0;

	//函数节流
	var throttle = function(fn, ctx, time){
		var args = Array.prototype.slice.call(arguments, 3);
		clearTimeout(fn._timer);
		fn._timer = setTimeout(function(){
			fn.apply(ctx, args);
		}, time);
	};

	//生成controller
	$sections.each(function(index){
		var $this = $(this),
			ctrl = $this.data('ctrl'),
			$el = $('<div class="ctrl-item ' + (!index && 'active') + '"></div>');

		$el.data('ctrl', ctrl);
		$el.append('<img src="' + ctrl.icon + '" /><span>' + ctrl.text + '</span>');
		$controller.append($el);
	});

	function slide(event, ui){
		var clientWidth = document.documentElement.clientWidth,
			maxV = clientWidth - $(ui.handle).width(),
			realV = ui.value * clientWidth / 100;

		$('#J-line').css('width', ui.value + '%');

		//console.log(ui.value);

		if(realV >= maxV){
			$(ui.handle).css('left', maxV);
			return false;
		}
	}
	//slider controll
	var totalProgressSlider = $("#totalProgressSlider").slider({
		range: false,
		min: 0,
		max: 100,
		step:.1,
		slide:slide
	});		
	
	//使controller居中
	$controller.css('marginTop', -$controller.height() / 2);

	//controller点击
	$(document).on('click', '.ctrl-item', function(){
		var $this = $(this),
			index = $this.index();

		if(currentSectionIndex === index){
			return false;
		}

		var ctrl = $this.data('ctrl'),
			outCallBack = CALLBACKS[$sections.eq(currentSectionIndex).data('ctrl').name] || {},
			InCallBack = CALLBACKS[ctrl.name] || {},
			switchOut = outCallBack.switchOut || $.noop,
			switchIn = InCallBack.switchIn || $.noop;

		
		$this.addClass('active')
			.siblings().removeClass('active');

		//controller样式切换，以适合背景
		$controller.attr('class', 'controller');
		ctrl.lighter && $controller.addClass(ctrl.lighter);

		//更新当前 section
		currentSectionIndex = index;

		//动画开始
		$wrap.completed = false;

		TweenLite.to($wrap, 0.7, {
			top : -(index * 100) + '%',
			ease : 'Power4.easeInOut',
			onComplete : function(){
				var timeline = TIMELINES[ctrl.name];
				$wrap.completed = true;

				//移出
				switchOut();
				//移进
				switchIn();

				//清除其他section中正在运行的动画
				/*
				 *for(var i in TIMELINES){
				 *    if(TIMELINES[i] && typeof TIMELINES[i].pause === 'function'){
				 *        TIMELINES[i].pause();
				 *    }
				 *}
				 */
				//运行对应section中的timeline
				/*
				 *if(timeline){
				 *    timeline.restart();
				 *}else{
				 *    timeline = TIMELINES[ctrl.name] = new TimelineMax({
				 *        onUpdate : (CALLBACKS[ctrl.name] || {}).onUpdate || $.noop,
				 *        yoyo : true
				 *    });
				 *    typeof ADDLINES[ctrl.name] === 'function' && ADDLINES[ctrl.name](timeline);
				 *    timeline.play();
				 *}
				 */
			}
		});
	});

	//方向键事件
	$(document).keydown(function(e, k){
		var keyCode = e.keyCode || k,
			$ctrls = $('.ctrl-item'),
			length = $ctrls.length,
			index;

		if(!$wrap.completed){
			return false;
		}

		switch(keyCode){
			//向上
			case 38:
				index = currentSectionIndex - 1 <= 0 ? 0 : currentSectionIndex - 1;
				break;
			//向下
			case 40:
				index = currentSectionIndex + 1 >= length ? 
					length - 1 : currentSectionIndex + 1;
				break;
			//空格
			case 32:
				if(currentSectionIndex === 1){
					$('#J-play').trigger('click');
					return false;
				}else{
					return true;
				}
				break;
			default:
				return true;
		}
		$ctrls.eq(index).trigger('click');
	});

	//鼠标滚轮事件
	function switchSection(e){
		//< 0 down
		//> 0 up
		var keyCode = e.deltaY > 0 ? 38 : 40;
		$(document).trigger('keydown', keyCode);
	};

	$(document).mousewheel(function(e){
		//throttle(switchSection, this, 20, e);
	});


	//播放控制
	$('#J-play').click(function(){
		var $this = $(this),
			playing = !$this.hasClass('pc-pause');

		if(playing){
			$this.addClass('pc-pause');
			audio.pause();
		}else{
			$this.removeClass('pc-pause');
			audio.play();
		}
	});

	//声音控制
	$('#J-sound').click(function(){
		var $this = $(this),
			unmute = !$this.hasClass('pc-mute');
		
		if(unmute){
			$this.addClass('pc-mute');
			audio.volume = 0;
		}else{
			$this.removeClass('pc-mute');
			audio.volume = 1;
		}
	});

	//禁止双击选中文字
	document.onselectstart = function(){
		return false;
	};
});
